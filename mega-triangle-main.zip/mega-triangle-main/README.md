# mega-triangle

# Hi there!<img src="https://github.com/blackcater/blackcater/raw/main/images/Hi.gif" height="32"/></h1>

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Jersey+20&size=40&pause=1000&random=false&width=435&lines=This+is+an+example%3A" alt="Typing SVG" /></a>
# This program will make a triangle with the specified size "n"

![image](https://github.com/retroorb/mega-triangle/assets/165820499/b904ba0d-e0ee-4bdd-ae17-0207a3299dce)





